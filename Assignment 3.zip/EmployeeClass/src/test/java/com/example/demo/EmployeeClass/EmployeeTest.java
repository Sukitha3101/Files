package com.example.demo.EmployeeClass;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class EmployeeTest {

    @Test
    void testEmployeeAttributes() {
        // Create an Employee object
        Employee employee = new Employee(1, "John Doe", 50000.0);

        // Test attribute values using assertEquals
        assertEquals(1, employee.getId());
        assertEquals("John Doe", employee.getName());
        assertEquals(50000.0, employee.getSalary(), 0.001); // 0.001 tolerance for double comparison
    }

    @Test
    void testRaiseSalary() {
        // Create an Employee object
        Employee employee = new Employee(1, "Jane Smith", 60000.0);

        // Raise the salary
        employee.raiseSalary(5000.0);

        // Test if the salary was correctly increased
        assertEquals(65000.0, employee.getSalary(), 0.001); // 0.001 tolerance for double comparison
    }

    @Test
    void testEmployeeEquality() {
        // Create two Employee objects with same attributes
        Employee employee1 = new Employee(1, "John Doe", 50000.0);
        Employee employee2 = new Employee(1, "John Doe", 50000.0);

        // Check if both objects are equal
        assertEquals(employee1, employee2);
    }
}
