/**
 * 
 */
/**
 * @author thiru
 *
 */
module DayOfWeekFinder {
}