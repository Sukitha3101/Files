package StringReversal;

public class StringReversal {

	private static String input = null;
	public static String reverseString(String input2) {
		char[] charArray = input.toCharArray();
	    int left = 0;
	    int right = charArray.length - 1;
	    while (left < right) {
	    	char temp = charArray[left];
	    	charArray[left] = charArray[right];
	    	charArray[right] = temp;
	    	left++;
	    	right--;
	    }
	    return new String(charArray);
	}
	public static void main(String[] args) {
		 input = "Hello, World!";
		String reversed = reverseString(input);
		System.out.println("Original:" + input);
		System.out.println("Reversed:" + reversed);
	    }

	}


