package AgeCalculator;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;

public class AgeCalculator {

	public static void main(String[] args) {
		String birthdateStr = "1990-06-15";
		LocalDate birthdate = LocalDate.parse(birthdateStr, DateTimeFormatter.ISO_DATE);
		LocalDate currentDate = LocalDate.now();
		Period period = Period.between(birthdate, currentDate);
		int years = period.getYears();
		int months = period.getMonths();
		int days = period.getDays();
		System.out.printf("Age: %d months, %d months, %d days\n", years,months,days);
		
		

	}

}
