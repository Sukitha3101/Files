package DayOfWeekFinder;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class DayOfWeekFinder {

	public static void main(String[] args) {
		String dateStr = "2024-06-18";
		String dayOfWeek = findDayOfWeek(dateStr);
		System.out.println("Day of the week for " + dateStr + " is: " + dayOfWeek);
	}
	public static String findDayOfWeek(String dateStr) {
		LocalDate date = LocalDate.parse(dateStr, DateTimeFormatter.ISO_DATE);
		DayOfWeek dayOfWeek = date.getDayOfWeek();
		return dayOfWeek.toString();

	}

}
