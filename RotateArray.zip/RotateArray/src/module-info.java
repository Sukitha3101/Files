/**
 * 
 */
/**
 * @author thiru
 *
 */
module RotateArray {
}