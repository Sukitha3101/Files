package com.example.demo.EmployeeClass;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeClassApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeClassApplication.class, args);
	}

}
